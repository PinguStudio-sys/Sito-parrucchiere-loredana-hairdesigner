/**
 * Loredana & Francesco Hairdesigner - Script del Salone
 * Sviluppato da WebMaster Pro Service
 */

document.addEventListener('DOMContentLoaded', () => {
  initMobileNav();
  initHeaderScroll();
  initGalleryFilter();
  initLightbox();
  initLegalModals();
  initCookieBanner();
  initScrollTop();
  initFaqAccordion();
});

/* ---------------------------------------------------------
   1. Navigazione Mobile
--------------------------------------------------------- */
function initMobileNav() {
  const toggleBtn = document.getElementById('mobileToggle');
  const navMenu = document.getElementById('navMenu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (!toggleBtn || !navMenu) return;

  toggleBtn.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    const isExpanded = navMenu.classList.contains('active');
    toggleBtn.setAttribute('aria-expanded', isExpanded);
  });

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('active');
      toggleBtn.setAttribute('aria-expanded', 'false');
    });
  });
}

/* ---------------------------------------------------------
   2. Header Scroll Effect
--------------------------------------------------------- */
function initHeaderScroll() {
  const header = document.getElementById('mainHeader');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 30) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  }, { passive: true });
}

/* ---------------------------------------------------------
   3. Galleria Reale
--------------------------------------------------------- */
const galleryData = [
  {
    id: 1,
    src: 'assets/images/balayage-miele.jpg',
    category: 'lavori',
    title: 'Schiariture Biondo Miele',
    desc: 'Lavoro reale su misura: riflessi caldi e sfumature naturali.'
  },
  {
    id: 2,
    src: 'assets/images/onde-caramello.jpg',
    category: 'lavori',
    title: 'Onde Morbide Caramello',
    desc: 'Piega a onde naturali con sfumature calde e luminose.'
  },
  {
    id: 3,
    src: 'assets/images/salone-esterno.jpg',
    category: 'salone',
    title: 'Il Salone a Misterbianco',
    desc: 'Ingresso in Via S. Antonio Abate, 69 (Misterbianco).'
  }
];

let currentLightboxIndex = 0;
let currentFilteredList = [...galleryData];

function initGalleryFilter() {
  const filterBtns = document.querySelectorAll('.gallery-filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      galleryItems.forEach(item => {
        const itemCategory = item.getAttribute('data-category');
        if (filterValue === 'all' || itemCategory === filterValue) {
          item.classList.remove('hidden');
        } else {
          item.classList.add('hidden');
        }
      });

      if (filterValue === 'all') {
        currentFilteredList = [...galleryData];
      } else {
        currentFilteredList = galleryData.filter(item => item.category === filterValue);
      }
    });
  });
}

/* ---------------------------------------------------------
   4. Lightbox Ingrandimento Foto
--------------------------------------------------------- */
function initLightbox() {
  const modal = document.getElementById('lightboxModal');
  const imgElement = document.getElementById('lightboxImg');
  const titleElement = document.getElementById('lightboxTitle');
  const descElement = document.getElementById('lightboxDesc');
  const closeBtn = document.getElementById('lightboxClose');
  const prevBtn = document.getElementById('lightboxPrev');
  const nextBtn = document.getElementById('lightboxNext');
  const galleryItems = document.querySelectorAll('.gallery-item');

  if (!modal || !imgElement) return;

  function updateLightbox(index) {
    if (index < 0) index = currentFilteredList.length - 1;
    if (index >= currentFilteredList.length) index = 0;
    currentLightboxIndex = index;

    const data = currentFilteredList[currentLightboxIndex];
    if (!data) return;

    imgElement.src = data.src;
    imgElement.alt = data.title;
    titleElement.textContent = data.title;
    descElement.textContent = data.desc;
  }

  galleryItems.forEach(item => {
    item.addEventListener('click', () => {
      const id = parseInt(item.getAttribute('data-id'), 10);
      const foundIdx = currentFilteredList.findIndex(g => g.id === id);
      currentLightboxIndex = foundIdx !== -1 ? foundIdx : 0;
      updateLightbox(currentLightboxIndex);
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  });

  function closeLightbox() {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeLightbox();
  });

  if (prevBtn) {
    prevBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      updateLightbox(currentLightboxIndex - 1);
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      updateLightbox(currentLightboxIndex + 1);
    });
  }

  document.addEventListener('keydown', (e) => {
    if (!modal.classList.contains('active')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') updateLightbox(currentLightboxIndex - 1);
    if (e.key === 'ArrowRight') updateLightbox(currentLightboxIndex + 1);
  });
}

/* ---------------------------------------------------------
   5. Modali Legali (Privacy, Cookie, GDPR, Preferenze)
--------------------------------------------------------- */
function initLegalModals() {
  const legalTriggers = document.querySelectorAll('[data-legal-modal]');
  const closeBtns = document.querySelectorAll('.btn-legal-close');
  const legalModals = document.querySelectorAll('.legal-modal');

  legalTriggers.forEach(trigger => {
    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      const modalId = trigger.getAttribute('data-legal-modal');
      const targetModal = document.getElementById(modalId);
      if (targetModal) {
        targetModal.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  closeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      legalModals.forEach(m => m.classList.remove('active'));
      document.body.style.overflow = '';
    });
  });

  legalModals.forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  });
}

/* ---------------------------------------------------------
   6. Cookie Banner
--------------------------------------------------------- */
function initCookieBanner() {
  const banner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAcceptBtn');
  const essentialBtn = document.getElementById('cookieEssentialBtn');
  const prefSaveBtn = document.getElementById('saveCookiePrefsBtn');

  const consent = localStorage.getItem('lf_cookie_consent');

  if (!consent && banner) {
    setTimeout(() => {
      banner.classList.add('visible');
    }, 800);
  }

  function setConsent(type) {
    localStorage.setItem('lf_cookie_consent', type);
    if (banner) banner.classList.remove('visible');
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => setConsent('all'));
  }

  if (essentialBtn) {
    essentialBtn.addEventListener('click', () => setConsent('essential'));
  }

  if (prefSaveBtn) {
    prefSaveBtn.addEventListener('click', () => {
      setConsent('essential');
      const prefModal = document.getElementById('cookiePrefsModal');
      if (prefModal) prefModal.classList.remove('active');
      document.body.style.overflow = '';
    });
  }
}

/* ---------------------------------------------------------
   7. Torna su
--------------------------------------------------------- */
function initScrollTop() {
  const scrollBtn = document.getElementById('scrollTopBtn');
  if (!scrollBtn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      scrollBtn.classList.add('visible');
    } else {
      scrollBtn.classList.remove('visible');
    }
  }, { passive: true });

  scrollBtn.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
}

/* ---------------------------------------------------------
   8. FAQ Accordion
--------------------------------------------------------- */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  if (!faqItems.length) return;

  faqItems.forEach(item => {
    const btn = item.querySelector('.faq-question');
    const answer = item.querySelector('.faq-answer');
    if (!btn || !answer) return;

    btn.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');

      // Chiudi tutti gli altri
      faqItems.forEach(other => {
        if (other !== item) {
          other.classList.remove('open');
          const otherBtn = other.querySelector('.faq-question');
          const otherAns = other.querySelector('.faq-answer');
          if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          if (otherAns) otherAns.classList.remove('open');
        }
      });

      // Toggle item corrente
      item.classList.toggle('open', !isOpen);
      answer.classList.toggle('open', !isOpen);
      btn.setAttribute('aria-expanded', String(!isOpen));
    });
  });
}
